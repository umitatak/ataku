


SELECT 
g.generation, 
p.product_id, 
p.product, 
p.product_type, 
p.product_group, 
p.product_category, 
count(*) as number_of_sales
FROM [CaseStudy].[coffeeshop].[factsales] fs left join [CaseStudy].[coffeeshop].[dimproducts] p
on fs.product_id = p.product_id left join [CaseStudy].[coffeeshop].[dimgenerations] g 
on fs.customer_birth_year = g.birth_year 
where g.birth_year is not null
group by g.generation, p.product_id,  p.product, p.product_type, p.product_group, p.product_category


