
WITH WEEKS AS (
SELECT B.*
FROM(
SELECT A.*,
row_number() over(partition by week_id order by number_of_sales desc) AS RN
FROM
(SELECT 
d.week_id, 
fs.product_id, 
p.product, 
p.product_type, 
p.product_group, 
p.product_category,
count(*) as number_of_sales
FROM [CaseStudy].[coffeeshop].[factsales] fs left join [CaseStudy].[coffeeshop].[dimdates] d
on fs.date_id = d.date_id left join [CaseStudy].[coffeeshop].[dimproducts] p
on fs.product_id = p.product_id
group by d.week_id, fs.product_id, p.product, p.product_type, p.product_group, p.product_category
) A
) B
)

SELECT *
FROM WEEKS
WHERE RN < 4


