USE CaseStudy
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO

CREATE TABLE coffeeshop.dimcustomers(
	customer_id INT PRIMARY KEY,
	home_store INT,
	customer_first_name VARCHAR (255),
	customer_email VARCHAR (255),
	customer_since DATE,
	loyality_card_number VARCHAR (255),
	birthdate DATE,
	gender VARCHAR (255),
	birth_year INT
);

CREATE TABLE coffeeshop.dimdates(
	date_id INT PRIMARY KEY,
	transaction_date DATE,
	week_id INT,
	week_desc VARCHAR (255),
	month_id INT,
	month_name VARCHAR (255),
	quarter_id INT,
	quarter_name VARCHAR (255),
	year_id INT 
);

CREATE TABLE coffeeshop.dimgenerations(
	birth_year INT PRIMARY KEY,
	generation VARCHAR (255) 
);

CREATE TABLE coffeeshop.diminventories(
	inventory_id VARCHAR (255) PRIMARY KEY,
	sales_outlet_id INT,
	date_id INT,
	transaction_date DATE,
	product_id INT,
	start_of_day INT,
	quantity_sold INT,
	waste INT,
	waste_percentage VARCHAR (255)
);


CREATE TABLE coffeeshop.dimproducts(
	product_id INT PRIMARY KEY,
	product_group VARCHAR (255),
	product_category VARCHAR (255),
	product VARCHAR (255),
	product_type VARCHAR (255),
	product_description VARCHAR (511),
	unit_of_measure VARCHAR (255),
	current_wholesale_price DECIMAL,
	current_retail_price VARCHAR (255),
	tax_exempt_yn VARCHAR (255),
	promo_yn VARCHAR (255),
	new_product_yn VARCHAR (255) 
);

CREATE TABLE coffeeshop.dimtargets(
	sales_outlet_id INT PRIMARY KEY,
	year_month VARCHAR (255),
	beans_goal INT,
	beverage_goal INT,
	food_goal INT,
	merchandise_goal INT,
	total_goal INT 
);

CREATE TABLE coffeeshop.dimoutlets(
	sales_outlet_id INT PRIMARY KEY,
	sales_outlet_type VARCHAR (255),
	store_square_feet INT,
	store_address VARCHAR (255),
	store_city VARCHAR (255),
	store_state_province VARCHAR (255),
	store_telephone VARCHAR (255),
	store_postal_code INT,
	store_longitude DECIMAL,
	store_latitude DECIMAL,
	manager INT,
	Neighorhood VARCHAR (255) 
);

CREATE TABLE coffeeshop.dimstaffs(
	staff_id INT PRIMARY KEY,
	first_name VARCHAR (255),
	last_name VARCHAR (255),
	position VARCHAR (255),
	staff_start_date DATE,
	staff_location VARCHAR (255) 
);


CREATE TABLE coffeeshop.factsales(
	sales_id INT IDENTITY (1, 1) PRIMARY KEY,
	transaction_id INT,
	transaction_date DATE,
	date_id INT,
	transaction_time TIME,
	sales_outlet_id INT,
	staff_id INT,
	customer_birth_year INT,
	customer_id INT,
	inventory_id VARCHAR (255),
	instore_yn VARCHAR (255),
	order_no INT,
	line_item_id INT,
	product_id INT,
	quantity INT,
	line_item_amount INT,
	unit_price INT,
	promo_item_yn VARCHAR (255)
	--FOREIGN KEY (customer_id) REFERENCES coffeeshop.dimcustomers (customer_id) ON DELETE CASCADE ON UPDATE CASCADE,
	--FOREIGN KEY (date_id) REFERENCES coffeeshop.dimdates (date_id) ON DELETE CASCADE ON UPDATE CASCADE,
	--FOREIGN KEY (product_id) REFERENCES coffeeshop.dimproducts (product_id) ON DELETE CASCADE ON UPDATE CASCADE,
	--FOREIGN KEY (sales_outlet_id) REFERENCES coffeeshop.dimtargets (sales_outlet_id) ON DELETE CASCADE ON UPDATE CASCADE,
	--FOREIGN KEY (sales_outlet_id) REFERENCES coffeeshop.dimoutlets (sales_outlet_id)  ON DELETE CASCADE ON UPDATE CASCADE,
	--FOREIGN KEY (staff_id) REFERENCES coffeeshop.dimstaffs (staff_id)  ON DELETE CASCADE ON UPDATE CASCADE,
	--FOREIGN KEY (inventory_id) REFERENCES coffeeshop.diminventories (inventory_id)  ON DELETE CASCADE ON UPDATE CASCADE,
	--FOREIGN KEY (customer_birth_year) REFERENCES coffeeshop.dimgenerations (birth_year) ON DELETE CASCADE ON UPDATE CASCADE
);
